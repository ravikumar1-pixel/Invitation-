RITVIK'S NAMKARAN INVITATION WEBSITE

Files
- index.html: complete mobile-friendly invitation website. CSS and JavaScript are embedded, so no build tools or dependencies are needed.

Preview locally
1. Extract the ZIP (if using the ZIP).
2. Open index.html in Chrome, Edge, Safari, or another modern browser.

Included
- Cute pastel invitation design and teddy-bear illustration
- Event countdown to 24 October 2026, 6:00 PM India time
- Google Maps directions link
- WhatsApp / native share button
- Optional original synthesized chime melody (tap Play music; browsers require a user gesture)

Publishing online
Upload index.html to a static hosting provider such as GitHub Pages, Netlify, or Cloudflare Pages. After publishing, share the public URL with guests. The share button shares the event details; when hosted online, you can also share the website URL manually.

Event details
Ritvik's Namkaran Ceremony
Ravi & Laxmi
Saturday, 24 October 2026, 6:00 PM onwards
Royal Paper Banquet
E-1, Delhi – Peeragarhi Metro, Udyog Nagar, Industrial Area, New Delhi, Delhi 110041
